经过近一年的进一步收集整理，本语料库已扩展到3个领域：酒店、电脑(笔记本)与书籍。欢迎学术同行试用。
　　　未去重语料：

　　　1.ChnSentiCorp-Htl-ba-4000: 平衡语料，正负类各2000篇。
　　　2.ChnSentiCorp-NB-ba-4000: 平衡语料，正负类各2000篇。
　　　3.ChnSentiCorp-BK-ba-4000: 平衡语料，正负类各2000篇。
　　　去重后语料：
　　　1.ChnSentiCorp-Htl-del-4000: 平衡语料，正负类各2000篇。
　　　2.ChnSentiCorp-NB-del-4000: 平衡语料，正负类各2000篇。

　　　3.ChnSentiCorp-BK-del-4000: 平衡语料，正负类各2000篇。
